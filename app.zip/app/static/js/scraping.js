import { API } from "./api.js";

export function initScraping() {
    return API.executeScraping()
}